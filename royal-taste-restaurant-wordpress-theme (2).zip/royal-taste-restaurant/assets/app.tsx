
const RTIcon = ({name, className='', size=24, ...props}) => {
  const paths = {
    MenuIcon:'M4 6h16M4 12h16M4 18h16', X:'M6 6l12 12M18 6L6 18', ShoppingBag:'M6 8h12l1 12H5L6 8zm3 0a3 3 0 0 1 6 0', Star:'M12 3l2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3z', MapPin:'M12 21s7-5.2 7-11a7 7 0 1 0-14 0c0 5.8 7 11 7 11zM12 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4z', Phone:'M5 4l4 1-1 4a13 13 0 0 0 5 5l4-1 1 4c-1 2-4 3-6 2-5-2-8-5-10-10-1-2 0-5 3-5z', Mail:'M4 6h16v12H4zM4 7l8 6 8-6', Clock:'M12 7v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0', Calendar:'M5 4h14v16H5zM8 2v4M16 2v4M5 9h14', Users:'M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M10 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M20 21v-2a4 4 0 0 0-3-3M17 3a4 4 0 0 1 0 8', Check:'M5 12l4 4L19 6', ArrowUpRight:'M7 17L17 7M8 7h9v9', Search:'M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16zm6-2l4 4', Sparkles:'M12 3l1.2 5.8L19 12l-5.8 1.2L12 19l-1.2-5.8L5 12l5.8-3.2L12 3z', Copy:'M8 8h11v12H8zM5 16H4V4h12v1', CheckCircle2:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm-4 9l3 3 5-6', Utensils:'M7 3v7M4 3v4a3 3 0 0 0 6 0V3M7 10v11M16 3v18M16 3c4 2 4 7 0 8', ChevronRight:'M9 6l6 6-6 6', Plus:'M12 5v14M5 12h14', Minus:'M5 12h14', Trash2:'M6 7h12M9 7V4h6v3M8 10v7M12 10v7M16 10v7', ArrowRight:'M5 12h14M13 6l6 6-6 6'};
  return React.createElement('svg',{...props,width:size,height:size,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:'1.8',strokeLinecap:'round',strokeLinejoin:'round',className, 'aria-hidden':true}, React.createElement('path',{d:paths[name]||paths.Star}));
};
const MenuIcon = (props) => React.createElement(RTIcon, {name:'MenuIcon', ...props});
const X = (props) => React.createElement(RTIcon, {name:'X', ...props});
const ShoppingBag = (props) => React.createElement(RTIcon, {name:'ShoppingBag', ...props});
const Star = (props) => React.createElement(RTIcon, {name:'Star', ...props});
const MapPin = (props) => React.createElement(RTIcon, {name:'MapPin', ...props});
const Phone = (props) => React.createElement(RTIcon, {name:'Phone', ...props});
const Mail = (props) => React.createElement(RTIcon, {name:'Mail', ...props});
const Clock = (props) => React.createElement(RTIcon, {name:'Clock', ...props});
const Calendar = (props) => React.createElement(RTIcon, {name:'Calendar', ...props});
const Users = (props) => React.createElement(RTIcon, {name:'Users', ...props});
const Check = (props) => React.createElement(RTIcon, {name:'Check', ...props});
const ArrowUpRight = (props) => React.createElement(RTIcon, {name:'ArrowUpRight', ...props});
const Search = (props) => React.createElement(RTIcon, {name:'Search', ...props});
const Sparkles = (props) => React.createElement(RTIcon, {name:'Sparkles', ...props});
const Copy = (props) => React.createElement(RTIcon, {name:'Copy', ...props});
const CheckCircle2 = (props) => React.createElement(RTIcon, {name:'CheckCircle2', ...props});
const Utensils = (props) => React.createElement(RTIcon, {name:'Utensils', ...props});
const ChevronRight = (props) => React.createElement(RTIcon, {name:'ChevronRight', ...props});
const Plus = (props) => React.createElement(RTIcon, {name:'Plus', ...props});
const Minus = (props) => React.createElement(RTIcon, {name:'Minus', ...props});
const Trash2 = (props) => React.createElement(RTIcon, {name:'Trash2', ...props});
const ArrowRight = (props) => React.createElement(RTIcon, {name:'ArrowRight', ...props});

type MenuCategory =
  | 'Starters'
  | 'BBQ'
  | 'Burgers'
  | 'Pizza'
  | 'Main Course'
  | 'Desserts'
  | 'Drinks';

interface MenuItem {
  id: string;
  name: string;
  category: MenuCategory;
  description: string;
  pairingNote: string;
  price: number;
  prepTime: string;
  signature?: boolean;
  spicy?: boolean;
  vegetarian?: boolean;
  visualKey: string;
}

interface SpecialOffer {
  id: string;
  badgeText: string;
  title: string;
  subtitle: string;
  description: string;
  includes: string[];
  originalPrice: number;
  offerPrice: number;
  discountLabel: string;
  validUntil: string;
  visualKey: string;
}

interface GalleryItem {
  id: string;
  title: string;
  category:
    | 'Delicious Food'
    | 'Restaurant Interior'
    | 'Restaurant Exterior'
    | 'Dining Area'
    | 'Chef Preparation'
    | 'Special Dishes';
  caption: string;
  lightingNote: string;
  visualKey: string;
  spanClass: string;
}

interface CustomerReview {
  id: string;
  name: string;
  role: string;
  avatarKey: string;
  rating: number;
  review: string;
  dishOrdered: string;
  visitedDate: string;
}

const MENU_CATEGORIES: MenuCategory[] = [
  'Starters',
  'BBQ',
  'Burgers',
  'Pizza',
  'Main Course',
  'Desserts',
  'Drinks',
];

const MENU_ITEMS: MenuItem[] = [
  // Starters
  {
    id: 'starter-wagyu-carpaccio',
    name: 'A5 Wagyu Beef Carpaccio',
    category: 'Starters',
    description:
      'Paper-thin Miyazaki Wagyu seared over white binchotan charcoal, black winter truffle emulsion, aged Parmigiano-Reggiano curls, and cold-pressed olive oil.',
    pairingNote: 'Pairs with Smoked Rosemary Old Fashioned',
    price: 26,
    prepTime: '12 min',
    signature: true,
    visualKey: 'starter_carpaccio',
  },
  {
    id: 'starter-burrata-fig',
    name: 'Heirloom Burrata & Roasted Fig',
    category: 'Starters',
    description:
      'Creamy Pugliese burrata over charred sourdough, Mission figs glazed in aged Modena balsamic, crushed pistachios, and wildflower honeycomb.',
    pairingNote: 'Pairs with Spiced Pomegranate Spritz',
    price: 21,
    prepTime: '10 min',
    vegetarian: true,
    visualKey: 'starter_burrata',
  },
  {
    id: 'starter-scallops',
    name: 'Pan-Seared Hokkaido Scallops',
    category: 'Starters',
    description:
      'Diver scallops caramelized in cultured brown butter, velvety saffron cauliflower purée, crispy pancetta dust, and micro-chives.',
    pairingNote: 'Pairs with Golden Citrus Elixir',
    price: 28,
    prepTime: '14 min',
    signature: true,
    visualKey: 'starter_scallops',
  },

  // BBQ
  {
    id: 'bbq-wagyu-tomahawk',
    name: 'Wood-Fired Wagyu Tomahawk',
    category: 'BBQ',
    description:
      '32oz bone-in Australian Wagyu ribeye flame-seared over aged red oak and hickory embers, basted with roasted bone marrow and smoked rosemary butter.',
    pairingNote: 'Serves 1–2 · Carved tableside on hot slate',
    price: 118,
    prepTime: '28 min',
    signature: true,
    visualKey: 'bbq_tomahawk',
  },
  {
    id: 'bbq-smoked-brisket',
    name: '16-Hour Oak-Smoked Prime Brisket',
    category: 'BBQ',
    description:
      'USDA Prime black-bark brisket smoked low and slow over post oak, served with espresso-bourbon jus, pickled red chilies, and charred brioche.',
    pairingNote: 'Pitmaster Reserve · Limited nightly batch',
    price: 44,
    prepTime: '18 min',
    signature: true,
    visualKey: 'bbq_brisket',
  },
  {
    id: 'bbq-short-ribs',
    name: 'Crimson Glazed Iberico & Beef Short Ribs',
    category: 'BBQ',
    description:
      'Double-cut bone-in short ribs lacquered in pomegranate-chili BBQ reduction, topped with toasted sesame, crispy shallots, and herb slaw.',
    pairingNote: 'Rich & smoky with a warm chili finish',
    price: 48,
    prepTime: '22 min',
    spicy: true,
    visualKey: 'bbq_ribs',
  },

  // Burgers
  {
    id: 'burger-royal-truffle',
    name: 'The Royal Black Truffle Wagyu Burger',
    category: 'Burgers',
    description:
      'Double dry-aged Wagyu smash patties, cave-aged Gruyère, black truffle aioli, caramelized Vidalia shallots, and gold-dusted artisan brioche bun.',
    pairingNote: 'Served with triple-cooked duck-fat fries',
    price: 32,
    prepTime: '16 min',
    signature: true,
    visualKey: 'burger_truffle',
  },
  {
    id: 'burger-smokehouse-crimson',
    name: 'Smokehouse Brisket & Bone Marrow Burger',
    category: 'Burgers',
    description:
      'Prime chuck and brisket blend topped with thick-cut applewood bacon, smoked cheddar fondue, crispy onion strings, and crimson chipotle glaze.',
    pairingNote: 'Served with smoked sea-salt fries',
    price: 29,
    prepTime: '16 min',
    spicy: true,
    visualKey: 'burger_smokehouse',
  },
  {
    id: 'burger-wild-mushroom',
    name: 'Charred Maitake & Halloumi Brioche',
    category: 'Burgers',
    description:
      'Wood-roasted wild maitake mushroom cluster, seared Cypriot halloumi, black garlic emulsion, baby arugula, and pickled heirloom tomato.',
    pairingNote: 'Served with truffle parmesan fries',
    price: 26,
    prepTime: '15 min',
    vegetarian: true,
    visualKey: 'burger_mushroom',
  },

  // Pizza
  {
    id: 'pizza-tartufo-oro',
    name: 'Tartufo d’Oro Wood-Fired Pizza',
    category: 'Pizza',
    description:
      '72-hour fermented sourdough crust blistered at 900°F, fior di latte, wild porcini mushrooms, black truffle carpaccio, and aged fontina.',
    pairingNote: 'Blistered in our custom Acunto Naples oven',
    price: 34,
    prepTime: '14 min',
    signature: true,
    vegetarian: true,
    visualKey: 'pizza_truffle',
  },
  {
    id: 'pizza-diavola-crimson',
    name: 'Diavola Reale & Hot Honey',
    category: 'Pizza',
    description:
      'San Marzano DOP crushed tomatoes, artisanal soppressata piccante, creamy stracciatella, Calabrian chili oil, and organic wildflower hot honey.',
    pairingNote: 'Sweet heat with crisp charred leopard crust',
    price: 29,
    prepTime: '14 min',
    spicy: true,
    visualKey: 'pizza_diavola',
  },
  {
    id: 'pizza-smoked-wagyu',
    name: 'Smoked Brisket & Caramelized Fig Pizza',
    category: 'Pizza',
    description:
      'White garlic cream base, 16-hour smoked prime brisket ends, gorgonzola dolce, caramelized rosemary onions, and fresh baby rocket.',
    pairingNote: 'Rich, savory, and deeply aromatic',
    price: 33,
    prepTime: '15 min',
    visualKey: 'pizza_wagyu',
  },

  // Main Course
  {
    id: 'main-filet-rossini',
    name: 'Filet Mignon Rossini & Black Truffle Jus',
    category: 'Main Course',
    description:
      '8oz center-cut Prime tenderloin seared in clarified butter, served over potato mousseline, charred king oyster mushrooms, and Madeira truffle reduction.',
    pairingNote: 'Executive Chef Julian Vance’s signature dish',
    price: 64,
    prepTime: '24 min',
    signature: true,
    visualKey: 'main_filet',
  },
  {
    id: 'main-miso-chilean-seabass',
    name: 'Saffron & Honey-Glazed Chilean Sea Bass',
    category: 'Main Course',
    description:
      'Wild-caught Patagonian toothfish broiled with saffron-citrus glaze, forbidden black Forbidden rice, baby bok choy, and ginger-lemongrass velouté.',
    pairingNote: 'Silky, flaky texture with bright aromatic finish',
    price: 56,
    prepTime: '20 min',
    signature: true,
    visualKey: 'main_seabass',
  },
  {
    id: 'main-lobster-risotto',
    name: 'Butter-Poached Maine Lobster Risotto',
    category: 'Main Course',
    description:
      'Acquerello carnaroli rice simmered in roasted lobster bisque, whole butter-poached tail, saffron threads, Meyer lemon zest, and aged Parmigiano.',
    pairingNote: 'Prepared to order with Iranian saffron',
    price: 58,
    prepTime: '22 min',
    visualKey: 'main_risotto',
  },

  // Desserts
  {
    id: 'dessert-lava-cake',
    name: '24K Gold Dark Chocolate Molten Lava Cake',
    category: 'Desserts',
    description:
      'Warm 70% Valrhona Guanaja chocolate fondant with a liquid ganache heart, edible 24K gold leaf, Madagascar vanilla bean gelato, and crimson raspberry coulis.',
    pairingNote: 'Baked fresh · Please allow 14 minutes',
    price: 19,
    prepTime: '14 min',
    signature: true,
    vegetarian: true,
    visualKey: 'dessert_lava',
  },
  {
    id: 'dessert-saffron-pistachio',
    name: 'Royal Saffron & Bronte Pistachio Mille-Feuille',
    category: 'Desserts',
    description:
      'Crisp caramelized puff pastry layered with Iranian saffron diplomat cream, roasted Sicilian pistachio praline, and rosewater-infused berries.',
    pairingNote: 'Delicate, flaky, and lightly floral',
    price: 18,
    prepTime: '10 min',
    vegetarian: true,
    visualKey: 'dessert_millefeuille',
  },
  {
    id: 'dessert-tiramisu',
    name: 'Tableside Espresso & Mascarpone Tiramisu',
    category: 'Desserts',
    description:
      'House-baked savoiardi soaked in single-origin Ethiopian espresso, whipped mascarpone zabaglione, and Dutch-process dark cocoa.',
    pairingNote: 'Finished tableside with warm espresso pour',
    price: 17,
    prepTime: '8 min',
    vegetarian: true,
    visualKey: 'dessert_tiramisu',
  },

  // Drinks
  {
    id: 'drink-crimson-velvet',
    name: 'Royal Crimson Hibiscus & Smoked Cherry Elixir',
    category: 'Drinks',
    description:
      'Cold-brewed crimson hibiscus flower, muddled Amarena cherries, fresh blood orange, zero-proof botanical distillate, and aromatic hickory smoke bubble.',
    pairingNote: 'Zero-Proof Signature Botanical Craft',
    price: 16,
    prepTime: '5 min',
    signature: true,
    vegetarian: true,
    visualKey: 'drink_crimson',
  },
  {
    id: 'drink-gold-saffron-mule',
    name: 'Golden Saffron & Charred Pineapple Spritz',
    category: 'Drinks',
    description:
      'Wood-roasted pineapple infusion, saffron-cardamom cordial, fiery ginger beer, fresh lime juice, and 24K gold-dusted dehydrated citrus wheel.',
    pairingNote: 'Refreshing, spiced, and effervescent',
    price: 15,
    prepTime: '5 min',
    vegetarian: true,
    visualKey: 'drink_gold',
  },
  {
    id: 'drink-artisan-espresso',
    name: 'Velvet Roasted Hazelnut & Vanilla Bean Affogato Tonic',
    category: 'Drinks',
    description:
      'Double ristretto of dark-roasted Arabica beans layered over chilled Madagascar vanilla cream, toasted Piedmont hazelnut syrup, and cacao nibs.',
    pairingNote: 'Served chilled in crystal coupe glass',
    price: 14,
    prepTime: '4 min',
    vegetarian: true,
    visualKey: 'drink_espresso',
  },
];

const SPECIAL_OFFERS: SpecialOffer[] = [
  {
    id: 'offer-family-deal',
    badgeText: 'Family Deal – 20% OFF',
    title: 'The Royal Hearth Family Feast',
    subtitle: 'Curated for 4 to 6 Guests · Available Daily',
    description:
      'Gather around a grand wood-fired platter featuring our signature 16-hour smoked brisket, flame-seared ribeye slices, artisan pizza, and decadent desserts.',
    includes: [
      '24oz Sliced Prime Ribeye & 16-Hour Oak-Smoked Brisket Platter',
      'Tartufo d’Oro Wood-Fired Sourdough Pizza & Truffle Duck-Fat Fries',
      'Heirloom Burrata Starter & Charred Caesar Salad for the Table',
      '4 Signature Craft Drinks + Shared Gold Molten Lava Cake Sampler',
    ],
    originalPrice: 195,
    offerPrice: 156,
    discountLabel: 'Save $39 (20% OFF)',
    validUntil: 'Available for Dine-In & Pre-Order',
    visualKey: 'offer_family',
  },
  {
    id: 'offer-weekend-special',
    badgeText: 'Weekend Special',
    title: 'The Pitmaster’s Reserve Duo',
    subtitle: 'Friday through Sunday · 5:00 PM – 11:00 PM',
    description:
      'Celebrate the weekend with our limited-batch dry-aged cuts roasted over white oak embers, paired with signature sides and smoked botanical drinks.',
    includes: [
      '28-Day Dry-Aged Prime Ribeye (16oz) & Glazed Beef Short Ribs',
      'Roasted Bone Marrow Canoe with Black Garlic Sourdough Toast',
      'Charred Asparagus with Saffron Hollandaise & Truffle Potato Puree',
      '2 Royal Crimson Smoked Cherry Elixirs Included',
    ],
    originalPrice: 145,
    offerPrice: 116,
    discountLabel: 'Weekend Exclusive ($29 Off)',
    validUntil: 'Every Fri, Sat & Sun Evening',
    visualKey: 'offer_weekend',
  },
  {
    id: 'offer-couple-dinner',
    badgeText: 'Couple Dinner Deal',
    title: 'Candlelight Three-Course Tasting for Two',
    subtitle: 'Intimate Booth Seating · Complimentary Rose Petal Table Setup',
    description:
      'An unforgettable evening crafted for two. Enjoy a three-course progression from delicate starters to flame-kissed mains and our molten gold finale.',
    includes: [
      'Shared Starter: A5 Wagyu Carpaccio or Pan-Seared Hokkaido Scallops',
      'Two Mains: Filet Mignon Rossini or Saffron Chilean Sea Bass',
      'Shared Finale: 24K Gold Dark Chocolate Molten Lava Cake',
      'Two Artisan Craft Drinks + Private Velvet Alcove Priority',
    ],
    originalPrice: 165,
    offerPrice: 132,
    discountLabel: 'Complete Tasting for Two',
    validUntil: 'Available Nightly by Reservation or Order',
    visualKey: 'offer_couple',
  },
];

const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Wood-Fired Wagyu Tomahawk Presentation',
    category: 'Delicious Food',
    caption: '32oz Australian Wagyu ribeye rested over smoking rosemary branches and flaky Maldon sea salt.',
    lightingNote: 'Warm Hearth Side-Lighting · Tableside Carve',
    visualKey: 'bbq_tomahawk',
    spanClass: 'md:col-span-2 md:row-span-2',
  },
  {
    id: 'gal-2',
    title: 'The Grand Crimson Velvet & Brass Salon',
    category: 'Restaurant Interior',
    caption: 'Custom Venetian hand-blown amber chandeliers suspended above deep crimson velvet banquettes and dark walnut tables.',
    lightingNote: 'Evening Candlelight Atmosphere · Main Floor',
    visualKey: 'gallery_interior',
    spanClass: 'md:col-span-1 md:row-span-1',
  },
  {
    id: 'gal-3',
    title: '742 Royal Velvet Avenue Heritage Facade',
    category: 'Restaurant Exterior',
    caption: 'Cast-iron architectural entryway with warm brass lanterns, boxwood planters, and evening valet courtyard.',
    lightingNote: 'Twilight Golden Hour · Culinary District',
    visualKey: 'gallery_exterior',
    spanClass: 'md:col-span-1 md:row-span-1',
  },
  {
    id: 'gal-4',
    title: 'Executive Chef Julian Vance at the Live-Fire Hearth',
    category: 'Chef Preparation',
    caption: 'Precision plating with micro-herbs, saffron reduction, and white binchotan charcoal finishing in our open kitchen.',
    lightingNote: 'Open Kitchen Pass · Copper Heat Lamps',
    visualKey: 'about_chef',
    spanClass: 'md:col-span-1 md:row-span-1',
  },
  {
    id: 'gal-5',
    title: 'Private Candlelit Wine & Tasting Alcove',
    category: 'Dining Area',
    caption: 'Acoustic-lined obsidian stone cellar seating up to 14 guests for milestone celebrations and executive dinners.',
    lightingNote: 'Private Cellar Suite · Bespoke Tableware',
    visualKey: 'gallery_dining',
    spanClass: 'md:col-span-1 md:row-span-1',
  },
  {
    id: 'gal-6',
    title: '24K Gold Dark Chocolate Molten Lava Cake',
    category: 'Special Dishes',
    caption: 'Valrhona 70% dark chocolate fondant dusted with edible gold leaf and served with Madagascar vanilla bean gelato.',
    lightingNote: 'Pastry Pass · Warm Rim Lighting',
    visualKey: 'dessert_lava',
    spanClass: 'md:col-span-1 md:row-span-1',
  },
];

const INITIAL_REVIEWS: CustomerReview[] = [
  {
    id: 'rev-1',
    name: 'Eleanor Sterling',
    role: 'Culinary Critic & Editor, Manhattan Gastronomy Guide',
    avatarKey: 'avatar_eleanor',
    rating: 5,
    review:
      'We booked the Chef’s Counter for our anniversary and ordered the 32oz Wagyu Tomahawk and Hokkaido Scallops. The crust on the steak had an extraordinary oak-smoke complexity while remaining butter-tender from edge to edge. Easily the most refined live-fire dining room in the city.',
    dishOrdered: 'Wood-Fired Wagyu Tomahawk',
    visitedDate: 'September 2026',
  },
  {
    id: 'rev-2',
    name: 'Marcus Thorne',
    role: 'Managing Partner, Aurelia Architecture Studio',
    avatarKey: 'avatar_marcus',
    rating: 5,
    review:
      'Hosted six international clients with The Royal Hearth Family Feast. From the moment we stepped past the brass-lit facade into the crimson velvet salon, the hospitality was effortless. Every plate arrived piping hot, and the 16-hour smoked brisket left the entire table speechless.',
    dishOrdered: 'The Royal Hearth Family Feast',
    visitedDate: 'October 2026',
  },
  {
    id: 'rev-3',
    name: 'Sophia Al-Mansoor',
    role: 'Founder, Maison Velvet Luxury Hospitality',
    avatarKey: 'avatar_sophia',
    rating: 5,
    review:
      'The Couple Dinner Deal is unmatched in value and theater. Our server timed each course impeccably, and the 24K Gold Molten Lava Cake paired with the Royal Crimson Hibiscus Elixir felt like true Michelin-caliber artistry without any pretension.',
    dishOrdered: 'Candlelight Three-Course Tasting',
    visitedDate: 'September 2026',
  },
  {
    id: 'rev-4',
    name: 'David Chen-Kowalski',
    role: 'Executive Producer, Meridian Films',
    avatarKey: 'avatar_david',
    rating: 5,
    review:
      'I stopped in for a Friday lunch expecting a standard upscale burger, and the Royal Black Truffle Wagyu Burger completely reset my standards. The 72-hour sourdough Tartufo d’Oro pizza is equally phenomenal—blistered, airy, and rich with real porcini.',
    dishOrdered: 'Royal Black Truffle Wagyu Burger',
    visitedDate: 'August 2026',
  },
];

const RESTAURANT_INFO = {
  name: 'Royal Taste Restaurant',
  tagline: 'Delicious Food, Unforgettable Moments',
  address: '742 Royal Velvet Avenue, Culinary District, New York, NY 10013',
  phone: '+1 (212) 555-0198',
  email: 'concierge@royaltasterestaurant.com',
  privateEventsEmail: 'events@royaltasterestaurant.com',
  hours: [
    { days: 'Monday – Thursday', time: '12:00 PM – 10:30 PM', kitchenNote: 'Last seating 9:45 PM' },
    { days: 'Friday – Saturday', time: '12:00 PM – 11:30 PM', kitchenNote: 'Live-Fire Reserve until 11:00 PM' },
    { days: 'Sunday', time: '12:00 PM – 10:00 PM', kitchenNote: 'Family Roast & Full Menu' },
  ],
  seatingAreas: [
    'Main Crimson Velvet Salon',
    'Open-Fire Chef’s Counter',
    'Candlelight Wine Cellar Alcove',
    'Heated Courtyard Terrace',
  ],
  timeSlots: [
    '12:30 PM',
    '01:30 PM',
    '02:30 PM',
    '05:30 PM',
    '06:30 PM',
    '07:00 PM',
    '07:30 PM',
    '08:00 PM',
    '08:30 PM',
    '09:15 PM',
    '10:00 PM',
  ],
};

const heroWagyuSteakImg = (window.RoyalTasteTheme && window.RoyalTasteTheme.assets ? window.RoyalTasteTheme.assets : '') + '/hero_wagyu_steak_1791446627825.jpg';
const aboutChefKitchenImg = (window.RoyalTasteTheme && window.RoyalTasteTheme.assets ? window.RoyalTasteTheme.assets : '') + '/about_chef_kitchen_1791446642601.jpg';
const foodTruffleBurgerImg = (window.RoyalTasteTheme && window.RoyalTasteTheme.assets ? window.RoyalTasteTheme.assets : '') + '/food_truffle_burger_1791446655115.jpg';
const foodWoodfiredPizzaImg = (window.RoyalTasteTheme && window.RoyalTasteTheme.assets ? window.RoyalTasteTheme.assets : '') + '/food_woodfired_pizza_1791446666559.jpg';
const foodSeafoodScallopsImg = (window.RoyalTasteTheme && window.RoyalTasteTheme.assets ? window.RoyalTasteTheme.assets : '') + '/food_seafood_scallops_1791446682197.jpg';
const foodMoltenDessertImg = (window.RoyalTasteTheme && window.RoyalTasteTheme.assets ? window.RoyalTasteTheme.assets : '') + '/food_molten_dessert_1791446706283.jpg';

interface CulinaryVisualProps {
  visualKey: string;
  alt: string;
  className?: string;
  aspectClass?: string;
}

const REAL_PHOTO_MAP: Record<
  string,
  { src: string; filterClass?: string; objectPosClass?: string }
> = {
  // Hero & BBQ & Steaks
  hero_dining: {
    src: heroWagyuSteakImg,
    objectPosClass: 'object-center',
  },
  bbq_tomahawk: {
    src: heroWagyuSteakImg,
    objectPosClass: 'object-center',
  },
  bbq_brisket: {
    src: heroWagyuSteakImg,
    filterClass: 'contrast-110 saturate-110 brightness-95',
    objectPosClass: 'object-left',
  },
  bbq_ribs: {
    src: heroWagyuSteakImg,
    filterClass: 'contrast-105 saturate-125',
    objectPosClass: 'object-right',
  },
  main_filet: {
    src: heroWagyuSteakImg,
    filterClass: 'brightness-95 contrast-110',
    objectPosClass: 'object-center',
  },
  starter_carpaccio: {
    src: heroWagyuSteakImg,
    filterClass: 'saturate-115 contrast-105',
    objectPosClass: 'object-bottom',
  },

  // Chef & Restaurant Kitchen / Interior
  about_chef: {
    src: aboutChefKitchenImg,
    objectPosClass: 'object-center',
  },
  gallery_interior: {
    src: heroWagyuSteakImg,
    filterClass: 'brightness-90 contrast-110',
    objectPosClass: 'object-top',
  },
  gallery_exterior: {
    src: aboutChefKitchenImg,
    filterClass: 'contrast-110 brightness-95',
    objectPosClass: 'object-top',
  },
  gallery_dining: {
    src: heroWagyuSteakImg,
    filterClass: 'saturate-110 contrast-105',
    objectPosClass: 'object-center',
  },

  // Burgers
  burger_truffle: {
    src: foodTruffleBurgerImg,
    objectPosClass: 'object-center',
  },
  burger_smokehouse: {
    src: foodTruffleBurgerImg,
    filterClass: 'contrast-110 saturate-115',
    objectPosClass: 'object-left',
  },
  burger_mushroom: {
    src: foodTruffleBurgerImg,
    filterClass: 'brightness-95 contrast-105',
    objectPosClass: 'object-right',
  },

  // Wood-Fired Pizzas & Burrata
  pizza_truffle: {
    src: foodWoodfiredPizzaImg,
    objectPosClass: 'object-center',
  },
  pizza_diavola: {
    src: foodWoodfiredPizzaImg,
    filterClass: 'saturate-125 contrast-110',
    objectPosClass: 'object-left',
  },
  pizza_wagyu: {
    src: foodWoodfiredPizzaImg,
    filterClass: 'contrast-110 brightness-95',
    objectPosClass: 'object-right',
  },
  starter_burrata: {
    src: foodWoodfiredPizzaImg,
    filterClass: 'brightness-105 saturate-110',
    objectPosClass: 'object-center',
  },

  // Seafood & Starters & Risotto
  starter_scallops: {
    src: foodSeafoodScallopsImg,
    objectPosClass: 'object-center',
  },
  main_seabass: {
    src: foodSeafoodScallopsImg,
    filterClass: 'contrast-105 saturate-110',
    objectPosClass: 'object-left',
  },
  main_risotto: {
    src: foodSeafoodScallopsImg,
    filterClass: 'saturate-120 brightness-95',
    objectPosClass: 'object-right',
  },

  // Desserts & Craft Drinks
  dessert_lava: {
    src: foodMoltenDessertImg,
    objectPosClass: 'object-center',
  },
  dessert_millefeuille: {
    src: foodMoltenDessertImg,
    filterClass: 'brightness-105 contrast-105',
    objectPosClass: 'object-left',
  },
  dessert_tiramisu: {
    src: foodMoltenDessertImg,
    filterClass: 'contrast-110 saturate-95',
    objectPosClass: 'object-right',
  },
  drink_crimson: {
    src: foodMoltenDessertImg,
    filterClass: 'saturate-125 contrast-110',
    objectPosClass: 'object-top',
  },
  drink_gold: {
    src: foodSeafoodScallopsImg,
    filterClass: 'saturate-125 brightness-95',
    objectPosClass: 'object-top',
  },
  drink_espresso: {
    src: foodMoltenDessertImg,
    filterClass: 'contrast-115 brightness-90',
    objectPosClass: 'object-bottom',
  },

  // Special Offers
  offer_family: {
    src: foodWoodfiredPizzaImg,
    objectPosClass: 'object-center',
  },
  offer_weekend: {
    src: heroWagyuSteakImg,
    objectPosClass: 'object-center',
  },
  offer_couple: {
    src: foodMoltenDessertImg,
    objectPosClass: 'object-center',
  },
};

function buildAvatarSvg(visualKey: string): string {
  const hueShift = visualKey.includes('eleanor')
    ? '#8b1e24'
    : visualKey.includes('marcus')
      ? '#7c5c16'
      : visualKey.includes('sophia')
        ? '#6b1d2f'
        : '#2b3a4a';
  const initials = visualKey.includes('eleanor')
    ? 'ES'
    : visualKey.includes('marcus')
      ? 'MT'
      : visualKey.includes('sophia')
        ? 'SA'
        : 'DC';

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
    <defs>
      <linearGradient id="goldRim" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#f3d87d" />
        <stop offset="50%" stop-color="#d4af37" />
        <stop offset="100%" stop-color="#7c5c16" />
      </linearGradient>
    </defs>
    <rect width="200" height="200" rx="100" fill="${hueShift}" />
    <circle cx="100" cy="100" r="94" fill="none" stroke="url(#goldRim)" stroke-width="4" opacity="0.6" />
    <text x="100" y="118" text-anchor="middle" fill="#F7F5F0" font-family="Georgia, serif" font-size="56" font-weight="bold">${initials}</text>
  </svg>`;
}

const CulinaryVisual: React.FC<CulinaryVisualProps> = ({
  visualKey,
  alt,
  className = '',
  aspectClass = 'aspect-[4/3]',
}) => {
  const [imgError, setImgError] = useState(false);

  const resolvedPhoto = useMemo(() => {
    if (visualKey.startsWith('avatar_')) {
      const svg = buildAvatarSvg(visualKey);
      return {
        src: `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`,
        filterClass: '',
        objectPosClass: 'object-center',
      };
    }
    return (
      REAL_PHOTO_MAP[visualKey] || {
        src: heroWagyuSteakImg,
        filterClass: '',
        objectPosClass: 'object-center',
      }
    );
  }, [visualKey]);

  return (
    <div
      className={`relative overflow-hidden bg-[#121215] ${aspectClass} ${className}`}
    >
      {!imgError ? (
        <img
          src={resolvedPhoto.src}
          alt={alt}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className={`h-full w-full object-cover transition-transform duration-200 ease-out group-hover:scale-[1.03] ${
            resolvedPhoto.filterClass || ''
          } ${resolvedPhoto.objectPosClass || 'object-center'}`}
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#1B1214] via-[#121215] to-[#0A0A0B] p-4 text-center">
          <span className="font-serif text-lg text-[#D4AF37]">{alt}</span>
        </div>
      )}
    </div>
  );
};

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
  visualKey: string;
  note?: string;
}

interface OrderDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

const OrderDrawer: React.FC<OrderDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [fulfillmentType, setFulfillmentType] = useState<'delivery' | 'pickup' | 'dine-in'>('delivery');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [confirmedOrder, setConfirmedOrder] = useState<{
    orderNumber: string;
    total: number;
    itemCount: number;
    fulfillment: string;
    customerName: string;
  } | null>(null);
  const [formError, setFormError] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const serviceFee = subtotal > 0 ? (fulfillmentType === 'delivery' && subtotal < 100 ? 8 : 0) : 0;
  const tax = Math.round(subtotal * 0.08875 * 100) / 100;
  const total = subtotal + serviceFee + tax;

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) {
      setFormError('Please provide your name and phone number to confirm your order.');
      return;
    }
    if (fulfillmentType === 'delivery' && !customerAddress.trim()) {
      setFormError('Please enter your delivery address.');
      return;
    }

    setFormError('');
    const randomCode = Math.floor(1000 + Math.random() * 9000);
    setConfirmedOrder({
      orderNumber: `RTR-${randomCode}`,
      total,
      itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
      fulfillment:
        fulfillmentType === 'delivery'
          ? 'Chauffeur Thermal Delivery (35–45 min)'
          : fulfillmentType === 'pickup'
            ? 'Valet Curbside Pickup (20–25 min)'
            : 'Dine-In Table Pre-Order',
      customerName: customerName.trim(),
    });
    onClearCart();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm transition-opacity duration-200"
      role="dialog"
      aria-modal="true"
      aria-label="Your Royal Taste Order"
    >
      <div className="relative flex h-full w-full max-w-lg flex-col border-l border-white/10 bg-[#121215] text-[#F7F5F0] shadow-2xl">
        {/* Drawer Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-5">
          <div className="flex items-center gap-3">
            <ShoppingBag className="h-5 w-5 text-[#D4AF37]" />
            <h2 className="font-serif text-2xl font-semibold tracking-tight text-[#F7F5F0]">
              Royal Culinary Bag
            </h2>
          </div>
          <button
            type="button"
            onClick={() => {
              setConfirmedOrder(null);
              onClose();
            }}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 text-[#A6A29A] transition-colors duration-150 hover:border-[#D4AF37] hover:text-[#F7F5F0] focus-visible:outline-2 focus-visible:outline-[#D4AF37]"
            aria-label="Close order drawer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto px-6 py-6">
          {confirmedOrder ? (
            <div className="space-y-6 rounded-xl border border-[#D4AF37]/30 bg-[#18181C] p-6">
              <div className="flex items-center gap-3 text-[#D4AF37]">
                <CheckCircle2 className="h-7 w-7 shrink-0" />
                <div>
                  <p className="text-xs text-[#A6A29A]">Order Confirmed · Kitchen Fired</p>
                  <h3 className="font-serif text-2xl font-semibold text-[#F7F5F0]">
                    Order #{confirmedOrder.orderNumber}
                  </h3>
                </div>
              </div>

              <p className="text-sm leading-relaxed text-[#A6A29A]">
                Thank you, <span className="font-medium text-[#F7F5F0]">{confirmedOrder.customerName}</span>. Our
                culinary team has begun preparing your {confirmedOrder.itemCount} selected item(s).
              </p>

              <div className="space-y-2 border-y border-white/10 py-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#A6A29A]">Service Mode</span>
                  <span className="font-medium text-[#F7F5F0]">{confirmedOrder.fulfillment}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#A6A29A]">Payment Terms</span>
                  <span className="font-medium text-[#F7F5F0]">Card or Cash upon Arrival</span>
                </div>
                <div className="flex justify-between pt-2 text-base font-semibold">
                  <span className="text-[#D4AF37]">Total Amount</span>
                  <span className="font-mono tabular-nums text-[#D4AF37]">
                    ${confirmedOrder.total.toFixed(2)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setConfirmedOrder(null);
                  onClose();
                }}
                className="w-full rounded-lg bg-[#D4AF37] px-5 py-3 text-sm font-semibold text-[#0A0A0B] transition-colors duration-150 hover:bg-[#e3be42] whitespace-nowrap"
              >
                Return to Royal Taste Menu
              </button>
            </div>
          ) : items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center py-12 text-center">
              <ShoppingBag className="mb-4 h-12 w-12 text-[#A6A29A]/40" />
              <h3 className="font-serif text-2xl font-medium text-[#F7F5F0]">
                Your Culinary Bag is Empty
              </h3>
              <p className="mt-2 max-w-xs text-sm text-[#A6A29A]">
                Explore our wood-fired Wagyu cuts, artisan pizzas, and signature desserts to begin your order.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-6 rounded-lg border border-[#D4AF37]/50 px-5 py-2.5 text-sm font-medium text-[#D4AF37] transition-colors duration-150 hover:bg-[#D4AF37] hover:text-[#0A0A0B] whitespace-nowrap"
              >
                Browse Our Menu
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Fulfillment Mode Selector */}
              <div className="grid grid-cols-3 gap-1.5 rounded-lg bg-[#0A0A0B] p-1 border border-white/10">
                {(
                  [
                    { id: 'delivery', label: 'Delivery' },
                    { id: 'pickup', label: 'Valet Pickup' },
                    { id: 'dine-in', label: 'Dine-In Pre-Order' },
                  ] as const
                ).map((mode) => (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setFulfillmentType(mode.id)}
                    className={`rounded-md px-3 py-2 text-xs font-medium transition-colors duration-150 whitespace-nowrap truncate ${
                      fulfillmentType === mode.id
                        ? 'bg-[#D4AF37] text-[#0A0A0B] font-semibold'
                        : 'text-[#A6A29A] hover:text-[#F7F5F0]'
                    }`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>

              {/* Itemized List */}
              <div className="divide-y divide-white/10">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center gap-4 py-4">
                    <CulinaryVisual
                      visualKey={item.visualKey}
                      alt={item.name}
                      aspectClass="aspect-square"
                      className="h-16 w-16 shrink-0 rounded-lg border border-white/10"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-[#A6A29A]">{item.category}</p>
                      <h4 className="truncate text-sm font-semibold text-[#F7F5F0]">{item.name}</h4>
                      <p className="mt-0.5 font-mono text-sm tabular-nums text-[#D4AF37]">
                        ${(item.price * item.quantity).toFixed(2)}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="flex h-8 w-8 items-center justify-center rounded-md border border-white/15 bg-[#18181C] text-[#F7F5F0] transition-colors hover:border-[#D4AF37]"
                        aria-label={`Decrease quantity of ${item.name}`}
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-6 text-center font-mono text-xs tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="flex h-8 w-8 items-center justify-center rounded-md border border-white/15 bg-[#18181C] text-[#F7F5F0] transition-colors hover:border-[#D4AF37]"
                        aria-label={`Increase quantity of ${item.name}`}
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.id)}
                        className="ml-1 flex h-8 w-8 items-center justify-center rounded-md text-[#A6A29A] transition-colors hover:text-[#ef4444]"
                        aria-label={`Remove ${item.name}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Customer Verification Form */}
              <form id="order-checkout-form" onSubmit={handleCheckout} className="space-y-4 pt-2">
                <h3 className="font-serif text-lg font-semibold text-[#F7F5F0]">
                  Guest Dispatch Details
                </h3>
                {formError && (
                  <p className="rounded-lg border border-[#ef4444]/40 bg-[#8B1E24]/20 px-3 py-2 text-xs text-[#fca5a5]">
                    {formError}
                  </p>
                )}
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs text-[#A6A29A]">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Alexander Wright"
                      className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] placeholder-[#A6A29A]/50 focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-[#A6A29A]">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+1 (212) 555-0142"
                      className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] placeholder-[#A6A29A]/50 focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>
                </div>
                {fulfillmentType === 'delivery' && (
                  <div>
                    <label className="mb-1 block text-xs text-[#A6A29A]">
                      Delivery Address & Suite *
                    </label>
                    <input
                      type="text"
                      required
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      placeholder="450 Park Avenue, Suite 12B, New York"
                      className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] placeholder-[#A6A29A]/50 focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>
                )}
              </form>
            </div>
          )}
        </div>

        {/* Drawer Footer */}
        {!confirmedOrder && items.length > 0 && (
          <div className="border-t border-white/10 bg-[#0A0A0B] px-6 py-5">
            <div className="space-y-1.5 text-xs text-[#A6A29A]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums text-[#F7F5F0]">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Complimentary Delivery Over $100</span>
                <span className="font-mono tabular-nums text-[#F7F5F0]">
                  {serviceFee === 0 ? 'Free' : `$${serviceFee.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Hospitality Tax</span>
                <span className="font-mono tabular-nums text-[#F7F5F0]">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-t border-white/10 pt-2 text-base font-semibold text-[#F7F5F0]">
                <span>Total Due</span>
                <span className="font-mono tabular-nums text-[#D4AF37]">${total.toFixed(2)}</span>
              </div>
            </div>
            <button
              type="submit"
              form="order-checkout-form"
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-[#D4AF37] px-5 py-3 text-sm font-semibold text-[#0A0A0B] transition-colors duration-150 hover:bg-[#e3be42] whitespace-nowrap"
            >
              <span>Confirm Royal Order</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

function App() {
  // Navigation & Drawer State
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [orderDrawerOpen, setOrderDrawerOpen] = useState(false);

  // Menu Filter State
  const [selectedCategory, setSelectedCategory] = useState<MenuCategory | 'All'>('All');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | 'signature' | 'vegetarian' | 'spicy'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([
    {
      id: 'bbq-wagyu-tomahawk',
      name: 'Wood-Fired Wagyu Tomahawk',
      price: 118,
      quantity: 1,
      category: 'BBQ',
      visualKey: 'bbq_tomahawk',
    },
  ]);

  // Gallery Filter & Lightbox State
  const [galleryFilter, setGalleryFilter] = useState<string>('All');
  const [activeLightboxItem, setActiveLightboxItem] = useState<GalleryItem | null>(null);

  // Customer Reviews State
  const [reviews, setReviews] = useState<CustomerReview[]>(INITIAL_REVIEWS);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReviewName, setNewReviewName] = useState('');
  const [newReviewRole, setNewReviewRole] = useState('');
  const [newReviewDish, setNewReviewDish] = useState('Wood-Fired Wagyu Tomahawk');
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);

  // Reservation Form State
  const [resName, setResName] = useState('');
  const [resPhone, setResPhone] = useState('');
  const [resEmail, setResEmail] = useState('');
  const [resGuests, setResGuests] = useState('2 Guests');
  const [resDate, setResDate] = useState('2026-10-10');
  const [resTime, setResTime] = useState('07:30 PM');
  const [resSeating, setResSeating] = useState(RESTAURANT_INFO.seatingAreas[0]);
  const [resSpecialRequest, setResSpecialRequest] = useState('');
  const [resError, setResError] = useState('');
  const [confirmedReservation, setConfirmedReservation] = useState<{
    referenceCode: string;
    name: string;
    phone: string;
    email: string;
    guests: string;
    date: string;
    time: string;
    seating: string;
    specialRequest: string;
  } | null>(null);

  // Contact Utility State
  const [addressCopied, setAddressCopied] = useState(false);
  const [directionsMode, setDirectionsMode] = useState<'valet' | 'subway' | 'private'>('valet');

  // Filtered Menu Items
  const filteredMenuItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const matchesDietary =
        dietaryFilter === 'all' ||
        (dietaryFilter === 'signature' && item.signature) ||
        (dietaryFilter === 'vegetarian' && item.vegetarian) ||
        (dietaryFilter === 'spicy' && item.spicy);
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q);
      return matchesCategory && matchesDietary && matchesSearch;
    });
  }, [selectedCategory, dietaryFilter, searchQuery]);

  // Filtered Gallery Items
  const filteredGalleryItems = useMemo(() => {
    if (galleryFilter === 'All') return GALLERY_ITEMS;
    return GALLERY_ITEMS.filter((item) => item.category === galleryFilter);
  }, [galleryFilter]);

  const totalCartItems = useMemo(
    () => cart.reduce((sum, item) => sum + item.quantity, 0),
    [cart]
  );

  // Handlers
  const handleAddToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [
        ...prev,
        {
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: 1,
          category: item.category,
          visualKey: item.visualKey,
        },
      ];
    });
    setRecentlyAddedId(item.id);
    setTimeout(() => {
      setRecentlyAddedId((current) => (current === item.id ? null : current));
    }, 1600);
  };

  const handleAddOfferToCart = (offer: SpecialOffer) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === offer.id);
      if (existing) {
        return prev.map((i) => (i.id === offer.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [
        ...prev,
        {
          id: offer.id,
          name: `${offer.title} (${offer.badgeText})`,
          price: offer.offerPrice,
          quantity: 1,
          category: 'Special Offer',
          visualKey: offer.visualKey,
        },
      ];
    });
    setOrderDrawerOpen(true);
  };

  const handleReserveWithOffer = (offer: SpecialOffer) => {
    setResSpecialRequest(`Special Offer Requested: ${offer.title} (${offer.badgeText} - $${offer.offerPrice})`);
    if (offer.id === 'offer-family-deal') {
      setResGuests('5 Guests');
    } else {
      setResGuests('2 Guests');
    }
    const el = document.getElementById('reservation');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => (item.id === id ? { ...item, quantity: item.quantity + delta } : item))
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleReservationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resName.trim() || !resPhone.trim() || !resEmail.trim() || !resDate) {
      setResError('Please complete your full name, phone number, email address, and preferred date.');
      return;
    }
    setResError('');
    const code = `RTR-${Math.floor(1000 + Math.random() * 9000)}`;
    setConfirmedReservation({
      referenceCode: code,
      name: resName.trim(),
      phone: resPhone.trim(),
      email: resEmail.trim(),
      guests: resGuests,
      date: resDate,
      time: resTime,
      seating: resSeating,
      specialRequest: resSpecialRequest.trim() || 'Standard Candlelight Table Service',
    });
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewName.trim() || !newReviewText.trim()) return;
    const created: CustomerReview = {
      id: `rev-${Date.now()}`,
      name: newReviewName.trim(),
      role: newReviewRole.trim() || 'Verified Dining Guest',
      avatarKey: 'avatar_eleanor',
      rating: newReviewRating,
      review: newReviewText.trim(),
      dishOrdered: newReviewDish,
      visitedDate: 'October 2026',
    };
    setReviews((prev) => [created, ...prev]);
    setNewReviewName('');
    setNewReviewRole('');
    setNewReviewText('');
    setShowReviewForm(false);
  };

  const handleCopyAddress = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(RESTAURANT_INFO.address).catch(() => {});
    }
    setAddressCopied(true);
    setTimeout(() => setAddressCopied(false), 2000);
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navLinks = [
    { label: 'Home', id: 'home' },
    { label: 'About', id: 'about' },
    { label: 'Menu', id: 'menu' },
    { label: 'Offers', id: 'offers' },
    { label: 'Gallery', id: 'gallery' },
    { label: 'Reviews', id: 'reviews' },
    { label: 'Reservation', id: 'reservation' },
    { label: 'Contact', id: 'contact' },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#F7F5F0] selection:bg-[#D4AF37]/30 selection:text-[#F7F5F0]">
      {/* Sticky Navigation Bar — Strict 3-Zone Contract */}
      <header className="sticky top-0 z-40 h-16 border-b border-white/10 bg-[#0A0A0B]/95 backdrop-blur-md">
        <div className="mx-auto flex h-full max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          {/* Zone 1: Brand Title (Single text element wordmark) */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              scrollToSection('home');
            }}
            className="font-serif text-xl font-bold tracking-tight text-[#F7F5F0] transition-colors duration-150 hover:text-[#D4AF37] sm:text-2xl whitespace-nowrap shrink-0"
          >
            Royal Taste Restaurant
          </a>

          {/* Zone 2: Navigation Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden lg:flex items-center gap-6 text-sm font-medium text-[#A6A29A]"
          >
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(link.id);
                }}
                className="relative py-1 text-[#A6A29A] transition-colors duration-150 hover:text-[#F7F5F0] after:absolute after:bottom-0 after:left-0 after:h-[1.5px] after:w-0 after:bg-[#D4AF37] after:transition-all after:duration-150 hover:after:w-full whitespace-nowrap"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: Primary Actions + Mobile Menu Button */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setOrderDrawerOpen(true)}
              className="flex items-center gap-2 rounded-lg border border-white/15 bg-[#121215] px-3.5 py-2 text-xs font-medium text-[#F7F5F0] transition-colors duration-150 hover:border-[#D4AF37] whitespace-nowrap shrink-0"
              aria-label="Open order bag"
            >
              <ShoppingBag className="h-4 w-4 text-[#D4AF37]" />
              <span className="hidden sm:inline">Order Bag</span>
              <span className="font-mono tabular-nums text-[#D4AF37]">({totalCartItems})</span>
            </button>

            <button
              type="button"
              onClick={() => scrollToSection('reservation')}
              className="hidden sm:inline-flex items-center justify-center rounded-lg bg-[#D4AF37] px-4 py-2 text-xs font-semibold text-[#0A0A0B] transition-colors duration-150 hover:bg-[#e2be46] whitespace-nowrap shrink-0"
            >
              Book a Table
            </button>

            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 text-[#F7F5F0] transition-colors duration-150 hover:border-[#D4AF37] lg:hidden"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <MenuIcon className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Responsive Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="border-b border-white/10 bg-[#121215] px-4 pt-3 pb-6 shadow-2xl lg:hidden">
            <div className="grid grid-cols-2 gap-2">
              {navLinks.map((link) => (
                <a
                  key={link.id}
                  href={`#${link.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection(link.id);
                  }}
                  className="rounded-lg px-3 py-2.5 text-sm font-medium text-[#F7F5F0] transition-colors hover:bg-white/5 hover:text-[#D4AF37]"
                >
                  {link.label}
                </a>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-white/10 flex gap-3">
              <button
                type="button"
                onClick={() => scrollToSection('reservation')}
                className="flex-1 rounded-lg bg-[#D4AF37] py-2.5 text-xs font-semibold text-[#0A0A0B] text-center whitespace-nowrap"
              >
                Book a Table
              </button>
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setOrderDrawerOpen(true);
                }}
                className="flex-1 rounded-lg border border-white/15 bg-[#0A0A0B] py-2.5 text-xs font-medium text-[#F7F5F0] text-center whitespace-nowrap"
              >
                View Order ({totalCartItems})
              </button>
            </div>
          </div>
        )}
      </header>

      <main>
        {/* 1. HOME / HERO SECTION */}
        <section
          id="home"
          className="relative overflow-hidden border-b border-white/10 pt-10 pb-16 lg:pt-16 lg:pb-24"
        >
          {/* Full-Width Atmospheric Backdrop with Measured Scrim */}
          <div className="pointer-events-none absolute inset-0 z-0 opacity-45">
            <CulinaryVisual
              visualKey="hero_dining"
              alt="Royal Taste Restaurant Fine Dining Table"
              aspectClass="h-full w-full"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0B] via-[#0A0A0B]/85 to-[#0A0A0B]/40" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] via-[#0A0A0B]/30 to-[#0A0A0B]/70" />
          </div>

          <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
              {/* Hero Left Column: Editorial Statement & Actions */}
              <div className="lg:col-span-7 space-y-6">
                <div className="flex flex-wrap items-center gap-2 text-xs text-[#D4AF37] tracking-wide">
                  <span>Royal Taste Restaurant</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#F7F5F0]/80">{RESTAURANT_INFO.tagline}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#A6A29A]">Manhattan Culinary District</span>
                </div>

                <h1 className="font-serif text-5xl font-semibold tracking-tight text-[#F7F5F0] sm:text-6xl lg:text-7xl leading-[1.06]">
                  Taste the <span className="italic font-normal text-[#D4AF37]">Difference</span>
                </h1>

                <p className="max-w-2xl text-base leading-relaxed text-[#A6A29A] sm:text-lg">
                  Experience the theater of live-fire gastronomy. From 28-day dry-aged Wagyu ribeye
                  seared over white oak embers to 72-hour fermented artisan sourdough pizzas and
                  24K gold-dusted pastries, every plate is crafted for unforgettable moments.
                </p>

                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => scrollToSection('menu')}
                    className="inline-flex items-center gap-2.5 rounded-lg bg-[#D4AF37] px-6 py-3.5 text-sm font-semibold text-[#0A0A0B] transition-all duration-150 hover:bg-[#e5c148] hover:-translate-y-0.5 whitespace-nowrap"
                  >
                    <span>View Menu</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => scrollToSection('reservation')}
                    className="inline-flex items-center gap-2.5 rounded-lg border border-white/20 bg-[#121215]/90 px-6 py-3.5 text-sm font-semibold text-[#F7F5F0] transition-all duration-150 hover:border-[#D4AF37] hover:text-[#D4AF37] whitespace-nowrap"
                  >
                    <Calendar className="h-4 w-4 text-[#D4AF37]" />
                    <span>Book a Table</span>
                  </button>
                </div>

                {/* Unboxed Operational Metadata */}
                <div className="pt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-[#A6A29A] border-t border-white/10">
                  <span>Open Daily 12:00 PM – 11:30 PM</span>
                  <span aria-hidden="true">·</span>
                  <span>Complimentary Valet at 742 Royal Velvet Ave</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums text-[#D4AF37]">
                    Direct Line: +1 (212) 555-0198
                  </span>
                </div>
              </div>

              {/* Hero Right Column: Signature Dish Spotlight Card */}
              <div className="lg:col-span-5">
                <div className="group overflow-hidden rounded-2xl border border-white/10 bg-[#121215] shadow-2xl">
                  <CulinaryVisual
                    visualKey="bbq_tomahawk"
                    alt="32oz Wood-Fired Wagyu Tomahawk Steak"
                    aspectClass="aspect-[16/10]"
                  />
                  <div className="p-6 space-y-3">
                    <div className="flex items-center justify-between text-xs text-[#A6A29A]">
                      <span>Tonight’s Hearth Showcase · Chef’s Reserve</span>
                      <span className="font-mono tabular-nums text-[#D4AF37] font-semibold">
                        $118.00
                      </span>
                    </div>
                    <h2 className="font-serif text-2xl font-semibold text-[#F7F5F0]">
                      32oz Wood-Fired Wagyu Tomahawk
                    </h2>
                    <p className="text-sm text-[#A6A29A] leading-relaxed">
                      Flame-seared over aged red oak and hickory embers, basted tableside with
                      roasted bone marrow and smoked rosemary butter.
                    </p>
                    <div className="pt-2 flex items-center justify-between gap-4 border-t border-white/10">
                      <span className="text-xs text-[#A6A29A]">
                        Carved tableside · Serves 1–2 Guests
                      </span>
                      <button
                        type="button"
                        onClick={() => handleAddToCart(MENU_ITEMS[3])}
                        className="rounded-lg bg-[#8B1E24] px-4 py-2 text-xs font-semibold text-[#F7F5F0] transition-colors duration-150 hover:bg-[#a6242b] whitespace-nowrap"
                      >
                        Order Dish Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quantitative Proof Bar */}
            <div className="mt-14 grid grid-cols-2 gap-6 border-t border-white/10 pt-8 sm:grid-cols-4">
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-[#D4AF37] sm:text-3xl">
                  18+ Years
                </p>
                <p className="mt-1 text-xs text-[#A6A29A]">
                  Live-Fire Culinary Heritage since 2008
                </p>
              </div>
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-[#F7F5F0] sm:text-3xl">
                  100% Prime
                </p>
                <p className="mt-1 text-xs text-[#A6A29A]">
                  USDA Prime & Certified Miyazaki A5 Wagyu
                </p>
              </div>
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-[#F7F5F0] sm:text-3xl">
                  900°F Hearth
                </p>
                <p className="mt-1 text-xs text-[#A6A29A]">
                  Custom Acunto Naples Oven & Post-Oak Grill
                </p>
              </div>
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-[#D4AF37] sm:text-3xl">
                  4.9 / 5.0
                </p>
                <p className="mt-1 text-xs text-[#A6A29A]">
                  Verified Average Across 2,480+ Diners
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 2. ABOUT US SECTION */}
        <section id="about" className="border-b border-white/10 py-20 lg:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
              {/* Left Column: Visual Showcase */}
              <div className="lg:col-span-6 space-y-4">
                <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#121215]">
                  <CulinaryVisual
                    visualKey="about_chef"
                    alt="Executive Chef Julian Vance plating signature dishes at Royal Taste Restaurant"
                    aspectClass="aspect-[4/3]"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/10 px-6 py-4 text-xs text-[#A6A29A]">
                    <span>Executive Chef Julian Vance · Open Kitchen Pass</span>
                    <span className="text-[#D4AF37]">3-Time James Beard Semifinalist</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Editorial Story & 4 Pillars */}
              <div className="lg:col-span-6 space-y-6">
                <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                  <span>Our Culinary Story</span>
                  <span aria-hidden="true">·</span>
                  <span>Established 2008</span>
                </div>

                <h2 className="font-serif text-3xl font-semibold tracking-tight text-[#F7F5F0] sm:text-4xl lg:text-5xl">
                  Where Artisanal Fire Meets Timeless Hospitality
                </h2>

                <p className="text-base leading-relaxed text-[#A6A29A]">
                  Founded in the heart of the Culinary District,{' '}
                  <span className="text-[#F7F5F0] font-medium">Royal Taste Restaurant</span> was
                  envisioned as a sanctuary where old-world live-fire cooking meets contemporary
                  refinement. Every evening, our kitchen roars to life with the aroma of seasoned
                  white oak, Iranian saffron, and freshly baked sourdough.
                </p>

                {/* 4 Required Pillars with Clean Editorial Numbering */}
                <div className="grid grid-cols-1 gap-6 pt-4 sm:grid-cols-2">
                  <div className="border-t border-white/10 pt-4">
                    <h3 className="font-serif text-xl font-semibold text-[#F7F5F0]">
                      01. Fresh Daily Ingredients
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#A6A29A]">
                      We partner directly with Hudson Valley organic farms, day-boat Atlantic
                      fisheries, and heritage ranches for peak-harvest produce and ethical cuts.
                    </p>
                  </div>

                  <div className="border-t border-white/10 pt-4">
                    <h3 className="font-serif text-xl font-semibold text-[#F7F5F0]">
                      02. Uncompromising Quality
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#A6A29A]">
                      Every steak is dry-aged in-house for a minimum of 28 days in our Himalayan
                      salt-brick chamber, and every sauce is reduced from scratch daily.
                    </p>
                  </div>

                  <div className="border-t border-white/10 pt-4">
                    <h3 className="font-serif text-xl font-semibold text-[#F7F5F0]">
                      03. Master Culinary Chefs
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#A6A29A]">
                      Led by Executive Chef Julian Vance, our brigade brings decades of training
                      from Michelin-starred kitchens across Paris, Tokyo, and New York.
                    </p>
                  </div>

                  <div className="border-t border-white/10 pt-4">
                    <h3 className="font-serif text-xl font-semibold text-[#F7F5F0]">
                      04. White-Glove Service
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#A6A29A]">
                      From personalized beverage pairings to tableside tomahawk carving, our dining
                      room team anticipates every detail of your celebration.
                    </p>
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap items-center gap-4">
                  <button
                    type="button"
                    onClick={() => scrollToSection('reservation')}
                    className="rounded-lg bg-[#D4AF37] px-5 py-3 text-xs font-semibold text-[#0A0A0B] transition-colors duration-150 hover:bg-[#e5c148] whitespace-nowrap"
                  >
                    Reserve Your Evening
                  </button>
                  <button
                    type="button"
                    onClick={() => scrollToSection('gallery')}
                    className="rounded-lg border border-white/15 px-5 py-3 text-xs font-medium text-[#F7F5F0] transition-colors duration-150 hover:border-[#D4AF37] hover:text-[#D4AF37] whitespace-nowrap"
                  >
                    Explore Our Dining Rooms
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3. OUR MENU SECTION */}
        <section id="menu" className="border-b border-white/10 py-20 lg:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            {/* Section Header */}
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div>
                <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                  <span>Culinary Collection</span>
                  <span aria-hidden="true">·</span>
                  <span>7 Curated Categories</span>
                </div>
                <h2 className="mt-2 font-serif text-4xl font-semibold tracking-tight text-[#F7F5F0] sm:text-5xl">
                  Our Signature Menu
                </h2>
              </div>

              {/* Search & Dietary Controls */}
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <div className="relative">
                  <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-[#A6A29A]" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search Wagyu, truffle, pizza..."
                    aria-label="Search menu items"
                    className="w-full rounded-lg border border-white/15 bg-[#121215] py-2 pr-4 pl-10 text-xs text-[#F7F5F0] placeholder-[#A6A29A] focus:border-[#D4AF37] focus:outline-none sm:w-64"
                  />
                </div>

                {/* Interactive Dietary Filter Segmented Control */}
                <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-[#121215] p-1">
                  {(
                    [
                      { id: 'all', label: 'All' },
                      { id: 'signature', label: 'Signature' },
                      { id: 'vegetarian', label: 'Vegetarian' },
                      { id: 'spicy', label: 'Spicy' },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setDietaryFilter(tab.id)}
                      className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors duration-150 whitespace-nowrap ${
                        dietaryFilter === tab.id
                          ? 'bg-[#D4AF37] text-[#0A0A0B] font-semibold'
                          : 'text-[#A6A29A] hover:text-[#F7F5F0]'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Category Filter Bar (All 7 Required Categories) */}
            <div
              role="tablist"
              aria-label="Menu Categories"
              className="mt-8 flex items-center gap-2 overflow-x-auto border-b border-white/10 pb-4"
            >
              <button
                type="button"
                role="tab"
                aria-selected={selectedCategory === 'All'}
                onClick={() => setSelectedCategory('All')}
                className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors duration-150 whitespace-nowrap shrink-0 ${
                  selectedCategory === 'All'
                    ? 'bg-[#D4AF37] text-[#0A0A0B]'
                    : 'bg-[#121215] text-[#A6A29A] hover:text-[#F7F5F0] border border-white/10'
                }`}
              >
                All Categories ({MENU_ITEMS.length})
              </button>
              {MENU_CATEGORIES.map((category) => {
                const count = MENU_ITEMS.filter((i) => i.category === category).length;
                const isActive = selectedCategory === category;
                return (
                  <button
                    key={category}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setSelectedCategory(category)}
                    className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors duration-150 whitespace-nowrap shrink-0 ${
                      isActive
                        ? 'bg-[#D4AF37] text-[#0A0A0B]'
                        : 'bg-[#121215] text-[#A6A29A] hover:text-[#F7F5F0] border border-white/10'
                    }`}
                  >
                    {category} ({count})
                  </button>
                );
              })}
            </div>

            {/* Menu Grid */}
            {filteredMenuItems.length === 0 ? (
              <div className="mt-12 rounded-2xl border border-white/10 bg-[#121215] p-12 text-center">
                <p className="font-serif text-2xl text-[#F7F5F0]">
                  No dishes match your current filter selection.
                </p>
                <p className="mt-2 text-sm text-[#A6A29A]">
                  Try clearing your search query or switching back to all categories.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('All');
                    setDietaryFilter('all');
                    setSearchQuery('');
                  }}
                  className="mt-5 rounded-lg bg-[#D4AF37] px-5 py-2.5 text-xs font-semibold text-[#0A0A0B] whitespace-nowrap"
                >
                  Reset Menu Filters
                </button>
              </div>
            ) : (
              <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                {filteredMenuItems.map((item) => {
                  const isAdded = recentlyAddedId === item.id;
                  return (
                    <article
                      key={item.id}
                      className="group flex flex-col overflow-hidden rounded-xl border border-white/10 bg-[#121215] transition-transform duration-200 ease-out hover:-translate-y-0.5 hover:border-[#D4AF37]/40"
                    >
                      {/* Food Image (65–70% visual lead) */}
                      <CulinaryVisual
                        visualKey={item.visualKey}
                        alt={item.name}
                        aspectClass="aspect-[4/3]"
                      />

                      {/* Card Content */}
                      <div className="flex flex-1 flex-col justify-between p-6">
                        <div>
                          {/* Clean Unboxed Metadata with Middot Separators */}
                          <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#A6A29A]">
                            <span className="text-[#D4AF37]">{item.category}</span>
                            <span aria-hidden="true">·</span>
                            <span>{item.prepTime}</span>
                            {item.signature && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-[#F7F5F0]">Chef’s Signature</span>
                              </>
                            )}
                            {item.vegetarian && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span>Vegetarian</span>
                              </>
                            )}
                            {item.spicy && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-[#f87171]">Spicy Glaze</span>
                              </>
                            )}
                          </div>

                          {/* Dish Title & Tabular Price */}
                          <div className="mt-2 flex items-baseline justify-between gap-4">
                            <h3 className="font-serif text-xl font-semibold text-[#F7F5F0] group-hover:text-[#D4AF37] transition-colors">
                              {item.name}
                            </h3>
                            <span className="font-mono text-base font-semibold tabular-nums text-[#D4AF37] shrink-0">
                              ${item.price.toFixed(2)}
                            </span>
                          </div>

                          {/* Description */}
                          <p className="mt-2.5 text-sm leading-relaxed text-[#A6A29A]">
                            {item.description}
                          </p>
                        </div>

                        {/* Pairing Footer + Order Now Button */}
                        <div className="mt-6 flex items-center justify-between gap-3 border-t border-white/10 pt-4">
                          <span className="truncate text-xs text-[#A6A29A]" title={item.pairingNote}>
                            {item.pairingNote}
                          </span>

                          <button
                            type="button"
                            onClick={() => handleAddToCart(item)}
                            className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors duration-150 whitespace-nowrap shrink-0 ${
                              isAdded
                                ? 'bg-emerald-600 text-white'
                                : 'bg-[#D4AF37] text-[#0A0A0B] hover:bg-[#e5c148]'
                            }`}
                          >
                            {isAdded ? (
                              <>
                                <Check className="h-3.5 w-3.5" />
                                <span>Added</span>
                              </>
                            ) : (
                              <span>Order Now</span>
                            )}
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        {/* 4. SPECIAL OFFERS SECTION */}
        <section id="offers" className="border-b border-white/10 bg-[#0E0E11] py-20 lg:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
              <div>
                <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                  <span>Limited-Time Curated Experiences</span>
                  <span aria-hidden="true">·</span>
                  <span>Dine-In & Pre-Order</span>
                </div>
                <h2 className="mt-2 font-serif text-4xl font-semibold tracking-tight text-[#F7F5F0] sm:text-5xl">
                  Special Offers & Tasting Deals
                </h2>
              </div>
              <p className="max-w-md text-sm text-[#A6A29A]">
                Select any seasonal tasting package to order directly to your door or attach to your
                evening table reservation.
              </p>
            </div>

            <div className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-3">
              {SPECIAL_OFFERS.map((offer) => (
                <article
                  key={offer.id}
                  className="group flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#121215] transition-transform duration-200 hover:-translate-y-0.5 hover:border-[#D4AF37]/50"
                >
                  <div className="relative">
                    <CulinaryVisual
                      visualKey={offer.visualKey}
                      alt={offer.title}
                      aspectClass="aspect-[16/10]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#121215] via-transparent to-black/30" />
                    <div className="absolute top-4 left-4 rounded-md bg-[#8B1E24] px-3 py-1 text-xs font-semibold text-[#F7F5F0] shadow-lg">
                      {offer.badgeText}
                    </div>
                  </div>

                  <div className="flex flex-1 flex-col justify-between p-6">
                    <div>
                      <p className="text-xs text-[#D4AF37]">{offer.subtitle}</p>
                      <h3 className="mt-1 font-serif text-2xl font-semibold text-[#F7F5F0]">
                        {offer.title}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-[#A6A29A]">
                        {offer.description}
                      </p>

                      {/* Itemized Inclusions */}
                      <ul className="mt-4 space-y-2 border-t border-white/10 pt-4 text-xs text-[#F7F5F0]/90">
                        {offer.includes.map((inc, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="font-mono text-[#D4AF37]">0{idx + 1}.</span>
                            <span>{inc}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-6 border-t border-white/10 pt-5">
                      <div className="flex items-baseline justify-between">
                        <div>
                          <span className="text-xs text-[#A6A29A] line-through font-mono tabular-nums">
                            ${offer.originalPrice.toFixed(2)}
                          </span>
                          <span className="ml-2 font-mono text-2xl font-bold tabular-nums text-[#D4AF37]">
                            ${offer.offerPrice.toFixed(2)}
                          </span>
                        </div>
                        <span className="text-xs font-medium text-emerald-400">
                          {offer.discountLabel}
                        </span>
                      </div>

                      <div className="mt-4 grid grid-cols-2 gap-2.5">
                        <button
                          type="button"
                          onClick={() => handleAddOfferToCart(offer)}
                          className="rounded-lg bg-[#D4AF37] px-3.5 py-2.5 text-xs font-semibold text-[#0A0A0B] transition-colors duration-150 hover:bg-[#e5c148] whitespace-nowrap"
                        >
                          Order Deal Now
                        </button>
                        <button
                          type="button"
                          onClick={() => handleReserveWithOffer(offer)}
                          className="rounded-lg border border-white/15 bg-[#18181C] px-3.5 py-2.5 text-xs font-medium text-[#F7F5F0] transition-colors duration-150 hover:border-[#D4AF37] hover:text-[#D4AF37] whitespace-nowrap"
                        >
                          Book with Deal
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* 5. FOOD & RESTAURANT GALLERY SECTION */}
        <section id="gallery" className="border-b border-white/10 py-20 lg:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div>
                <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                  <span>Visual Atmosphere</span>
                  <span aria-hidden="true">·</span>
                  <span>Architecture, Hearth & Plating</span>
                </div>
                <h2 className="mt-2 font-serif text-4xl font-semibold tracking-tight text-[#F7F5F0] sm:text-5xl">
                  Food & Restaurant Gallery
                </h2>
              </div>

              {/* Gallery Category Filter */}
              <div className="flex flex-wrap gap-1.5">
                {[
                  'All',
                  'Delicious Food',
                  'Restaurant Interior',
                  'Restaurant Exterior',
                  'Dining Area',
                  'Chef Preparation',
                  'Special Dishes',
                ].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setGalleryFilter(cat)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors duration-150 whitespace-nowrap ${
                      galleryFilter === cat
                        ? 'bg-[#D4AF37] text-[#0A0A0B] font-semibold'
                        : 'border border-white/10 bg-[#121215] text-[#A6A29A] hover:text-[#F7F5F0]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Gallery Grid */}
            <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
              {filteredGalleryItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setActiveLightboxItem(item)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setActiveLightboxItem(item);
                    }
                  }}
                  role="button"
                  tabIndex={0}
                  className={`group relative cursor-pointer overflow-hidden rounded-2xl border border-white/10 bg-[#121215] ${
                    galleryFilter === 'All' ? item.spanClass : ''
                  }`}
                >
                  <CulinaryVisual
                    visualKey={item.visualKey}
                    alt={item.title}
                    aspectClass={
                      galleryFilter === 'All' && item.spanClass.includes('row-span-2')
                        ? 'aspect-[16/11] h-full'
                        : 'aspect-[4/3]'
                    }
                  />
                  {/* Measured Contrast Scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent transition-opacity duration-200" />

                  <div className="absolute inset-x-0 bottom-0 p-6">
                    <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                      <span>{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-[#A6A29A]">{item.lightingNote}</span>
                    </div>
                    <h3 className="mt-1 font-serif text-xl font-semibold text-[#F7F5F0] group-hover:text-[#D4AF37] transition-colors">
                      {item.title}
                    </h3>
                    <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-[#A6A29A]">
                      {item.caption}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 6. CUSTOMER REVIEWS SECTION */}
        <section id="reviews" className="border-b border-white/10 bg-[#0E0E11] py-20 lg:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div>
                <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                  <span>Guest Testimonials</span>
                  <span aria-hidden="true">·</span>
                  <span>4.9 / 5.0 Verified Dining Rating</span>
                </div>
                <h2 className="mt-2 font-serif text-4xl font-semibold tracking-tight text-[#F7F5F0] sm:text-5xl">
                  Acclaimed by Critics & Guests
                </h2>
              </div>

              <button
                type="button"
                onClick={() => setShowReviewForm((prev) => !prev)}
                className="self-start rounded-lg border border-[#D4AF37]/50 bg-[#121215] px-4 py-2.5 text-xs font-semibold text-[#D4AF37] transition-colors duration-150 hover:bg-[#D4AF37] hover:text-[#0A0A0B] whitespace-nowrap"
              >
                {showReviewForm ? 'Close Review Form' : 'Share Your Dining Experience'}
              </button>
            </div>

            {/* Interactive Guest Review Submission Form */}
            {showReviewForm && (
              <form
                onSubmit={handleReviewSubmit}
                className="mt-8 rounded-2xl border border-[#D4AF37]/30 bg-[#121215] p-6 space-y-4"
              >
                <h3 className="font-serif text-xl font-semibold text-[#F7F5F0]">
                  Submit Your Royal Taste Review
                </h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label className="mb-1 block text-xs text-[#A6A29A]">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      value={newReviewName}
                      onChange={(e) => setNewReviewName(e.target.value)}
                      placeholder="Victoria Vance"
                      className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2 text-sm text-[#F7F5F0] focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-[#A6A29A]">Title or City</label>
                    <input
                      type="text"
                      value={newReviewRole}
                      onChange={(e) => setNewReviewRole(e.target.value)}
                      placeholder="Wine Collector, Tribeca"
                      className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2 text-sm text-[#F7F5F0] focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-[#A6A29A]">Favorite Dish</label>
                    <select
                      value={newReviewDish}
                      onChange={(e) => setNewReviewDish(e.target.value)}
                      className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2 text-sm text-[#F7F5F0] focus:border-[#D4AF37] focus:outline-none"
                    >
                      {MENU_ITEMS.map((item) => (
                        <option key={item.id} value={item.name}>
                          {item.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#A6A29A]">Your Review *</label>
                  <textarea
                    rows={3}
                    required
                    value={newReviewText}
                    onChange={(e) => setNewReviewText(e.target.value)}
                    placeholder="Share how the food, ambiance, and service made your evening memorable..."
                    className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2 text-sm text-[#F7F5F0] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                    <span>Rating: 5.0 / 5.0 Stars</span>
                  </div>
                  <button
                    type="submit"
                    className="rounded-lg bg-[#D4AF37] px-5 py-2 text-xs font-semibold text-[#0A0A0B] hover:bg-[#e5c148] whitespace-nowrap"
                  >
                    Publish Review
                  </button>
                </div>
              </form>
            )}

            {/* Testimonial Cards Grid */}
            <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2">
              {reviews.map((rev) => (
                <article
                  key={rev.id}
                  className="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#121215] p-6 sm:p-8"
                >
                  <div>
                    {/* 5-Star Rating + Unboxed Dish Metadata */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div
                        className="flex items-center gap-1 text-[#D4AF37]"
                        aria-label={`${rev.rating} out of 5 stars`}
                      >
                        {Array.from({ length: rev.rating }).map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-[#D4AF37] text-[#D4AF37]" />
                        ))}
                        <span className="ml-1.5 font-mono text-xs tabular-nums text-[#F7F5F0]">
                          5.0
                        </span>
                      </div>
                      <span className="text-xs text-[#A6A29A]">
                        Ordered: {rev.dishOrdered} · {rev.visitedDate}
                      </span>
                    </div>

                    <blockquote className="mt-4 text-sm leading-relaxed text-[#F7F5F0]/90 sm:text-base">
                      “{rev.review}”
                    </blockquote>
                  </div>

                  {/* Customer Profile Attribution */}
                  <div className="mt-6 flex items-center gap-3.5 border-t border-white/10 pt-4">
                    <CulinaryVisual
                      visualKey={rev.avatarKey}
                      alt={rev.name}
                      aspectClass="aspect-square"
                      className="h-11 w-11 shrink-0 rounded-full border border-[#D4AF37]/40"
                    />
                    <div>
                      <h3 className="text-sm font-semibold text-[#F7F5F0]">{rev.name}</h3>
                      <p className="text-xs text-[#A6A29A]">{rev.role}</p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* 7. RESERVATION / BOOK A TABLE SECTION */}
        <section id="reservation" className="border-b border-white/10 py-20 lg:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
              {/* Left Column: Reservation Context & Private Dining Highlights */}
              <div className="lg:col-span-5 space-y-6">
                <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                  <span>Table Reservations</span>
                  <span aria-hidden="true">·</span>
                  <span>Instant Confirmation</span>
                </div>

                <h2 className="font-serif text-4xl font-semibold tracking-tight text-[#F7F5F0] sm:text-5xl">
                  Reserve Your Table at Royal Taste
                </h2>

                <p className="text-base leading-relaxed text-[#A6A29A]">
                  Whether you are planning an intimate candlelight dinner for two, a lively family
                  feast around our wood-fired tomahawk board, or an executive tasting in our wine
                  cellar alcove, our concierge reserves your table with zero wait time.
                </p>

                <div className="space-y-4 border-t border-white/10 pt-6 text-sm">
                  <div>
                    <h3 className="font-semibold text-[#F7F5F0]">Dining Room Dress & Atmosphere</h3>
                    <p className="mt-1 text-xs leading-relaxed text-[#A6A29A]">
                      Smart evening attire encouraged. Complimentary valet parking is provided at
                      our 742 Royal Velvet Avenue courtyard entrance.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#F7F5F0]">
                      Private Events & Sommelier Cellar (8–24 Guests)
                    </h3>
                    <p className="mt-1 text-xs leading-relaxed text-[#A6A29A]">
                      For private dining inquiries or custom tasting menus, call our concierge desk
                      at{' '}
                      <span className="font-mono tabular-nums text-[#D4AF37]">
                        {RESTAURANT_INFO.phone}
                      </span>
                      .
                    </p>
                  </div>
                </div>

                <div className="overflow-hidden rounded-xl border border-white/10 bg-[#121215]">
                  <CulinaryVisual
                    visualKey="gallery_interior"
                    alt="The Grand Crimson Velvet Salon at Royal Taste Restaurant"
                    aspectClass="aspect-[16/9]"
                  />
                </div>
              </div>

              {/* Right Column: Reservation Form / Confirmation State */}
              <div className="lg:col-span-7">
                <div className="rounded-2xl border border-white/10 bg-[#121215] p-6 sm:p-10 shadow-2xl">
                  {confirmedReservation ? (
                    <div className="space-y-6">
                      <div className="flex items-center gap-3 text-[#D4AF37]">
                        <CheckCircle2 className="h-8 w-8 shrink-0" />
                        <div>
                          <p className="text-xs text-[#A6A29A]">
                            Table Confirmed · Concierge Notified
                          </p>
                          <h3 className="font-serif text-3xl font-semibold text-[#F7F5F0]">
                            Reservation #{confirmedReservation.referenceCode}
                          </h3>
                        </div>
                      </div>

                      <p className="text-sm leading-relaxed text-[#A6A29A]">
                        We look forward to welcoming you,{' '}
                        <span className="font-semibold text-[#F7F5F0]">
                          {confirmedReservation.name}
                        </span>
                        . A confirmation pass has been registered for{' '}
                        <span className="text-[#F7F5F0]">{confirmedReservation.email}</span>.
                      </p>

                      <div className="grid grid-cols-1 gap-4 rounded-xl border border-white/10 bg-[#0A0A0B] p-5 text-sm sm:grid-cols-2">
                        <div>
                          <span className="text-xs text-[#A6A29A]">Date & Seating Time</span>
                          <p className="mt-0.5 font-mono font-semibold tabular-nums text-[#D4AF37]">
                            {confirmedReservation.date} at {confirmedReservation.time}
                          </p>
                        </div>
                        <div>
                          <span className="text-xs text-[#A6A29A]">Party Size</span>
                          <p className="mt-0.5 font-mono font-semibold tabular-nums text-[#F7F5F0]">
                            {confirmedReservation.guests}
                          </p>
                        </div>
                        <div>
                          <span className="text-xs text-[#A6A29A]">Preferred Dining Zone</span>
                          <p className="mt-0.5 font-medium text-[#F7F5F0]">
                            {confirmedReservation.seating}
                          </p>
                        </div>
                        <div>
                          <span className="text-xs text-[#A6A29A]">Contact Phone</span>
                          <p className="mt-0.5 font-mono tabular-nums text-[#F7F5F0]">
                            {confirmedReservation.phone}
                          </p>
                        </div>
                        <div className="sm:col-span-2 border-t border-white/10 pt-3">
                          <span className="text-xs text-[#A6A29A]">Special Request / Package</span>
                          <p className="mt-0.5 text-xs text-[#F7F5F0]">
                            {confirmedReservation.specialRequest}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setConfirmedReservation(null)}
                          className="rounded-lg bg-[#D4AF37] px-5 py-2.5 text-xs font-semibold text-[#0A0A0B] transition-colors hover:bg-[#e5c148] whitespace-nowrap"
                        >
                          Modify or Make Another Reservation
                        </button>
                        <button
                          type="button"
                          onClick={() => scrollToSection('menu')}
                          className="rounded-lg border border-white/15 px-5 py-2.5 text-xs font-medium text-[#F7F5F0] transition-colors hover:border-[#D4AF37] whitespace-nowrap"
                        >
                          Pre-Order Dishes for Your Table
                        </button>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleReservationSubmit} className="space-y-5">
                      <div className="border-b border-white/10 pb-4">
                        <h3 className="font-serif text-2xl font-semibold text-[#F7F5F0]">
                          Book a Table
                        </h3>
                        <p className="mt-1 text-xs text-[#A6A29A]">
                          Complete the reservation details below for instant table allocation.
                        </p>
                      </div>

                      {resError && (
                        <p className="rounded-lg border border-[#ef4444]/40 bg-[#8B1E24]/25 px-4 py-2.5 text-xs text-[#fca5a5]">
                          {resError}
                        </p>
                      )}

                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        {/* 1. Full Name */}
                        <div>
                          <label
                            htmlFor="res-name"
                            className="mb-1.5 block text-xs font-medium text-[#A6A29A]"
                          >
                            Full Name *
                          </label>
                          <input
                            id="res-name"
                            type="text"
                            required
                            value={resName}
                            onChange={(e) => setResName(e.target.value)}
                            placeholder="Eleanor Sterling"
                            className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] placeholder-[#A6A29A]/40 focus:border-[#D4AF37] focus:outline-none"
                          />
                        </div>

                        {/* 2. Phone Number */}
                        <div>
                          <label
                            htmlFor="res-phone"
                            className="mb-1.5 block text-xs font-medium text-[#A6A29A]"
                          >
                            Phone Number *
                          </label>
                          <input
                            id="res-phone"
                            type="tel"
                            required
                            value={resPhone}
                            onChange={(e) => setResPhone(e.target.value)}
                            placeholder="+1 (212) 555-0192"
                            className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] placeholder-[#A6A29A]/40 focus:border-[#D4AF37] focus:outline-none"
                          />
                        </div>

                        {/* 3. Email Address */}
                        <div>
                          <label
                            htmlFor="res-email"
                            className="mb-1.5 block text-xs font-medium text-[#A6A29A]"
                          >
                            Email Address *
                          </label>
                          <input
                            id="res-email"
                            type="email"
                            required
                            value={resEmail}
                            onChange={(e) => setResEmail(e.target.value)}
                            placeholder="eleanor@sterling.com"
                            className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] placeholder-[#A6A29A]/40 focus:border-[#D4AF37] focus:outline-none"
                          />
                        </div>

                        {/* 4. Number of Guests */}
                        <div>
                          <label
                            htmlFor="res-guests"
                            className="mb-1.5 block text-xs font-medium text-[#A6A29A]"
                          >
                            Number of Guests *
                          </label>
                          <select
                            id="res-guests"
                            value={resGuests}
                            onChange={(e) => setResGuests(e.target.value)}
                            className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] focus:border-[#D4AF37] focus:outline-none"
                          >
                            {[
                              '1 Guest',
                              '2 Guests',
                              '3 Guests',
                              '4 Guests',
                              '5 Guests',
                              '6 Guests',
                              '8 Guests (Large Table)',
                              '10+ Guests (Private Wine Alcove)',
                            ].map((opt) => (
                              <option key={opt} value={opt}>
                                {opt}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* 5. Date */}
                        <div>
                          <label
                            htmlFor="res-date"
                            className="mb-1.5 block text-xs font-medium text-[#A6A29A]"
                          >
                            Reservation Date *
                          </label>
                          <input
                            id="res-date"
                            type="date"
                            required
                            value={resDate}
                            onChange={(e) => setResDate(e.target.value)}
                            className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 font-mono text-sm tabular-nums text-[#F7F5F0] focus:border-[#D4AF37] focus:outline-none"
                          />
                        </div>

                        {/* 6. Time */}
                        <div>
                          <label
                            htmlFor="res-time"
                            className="mb-1.5 block text-xs font-medium text-[#A6A29A]"
                          >
                            Preferred Seating Time *
                          </label>
                          <select
                            id="res-time"
                            value={resTime}
                            onChange={(e) => setResTime(e.target.value)}
                            className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 font-mono text-sm tabular-nums text-[#F7F5F0] focus:border-[#D4AF37] focus:outline-none"
                          >
                            {RESTAURANT_INFO.timeSlots.map((slot) => (
                              <option key={slot} value={slot}>
                                {slot}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Dining Room Preference */}
                      <div>
                        <label className="mb-1.5 block text-xs font-medium text-[#A6A29A]">
                          Seating Atmosphere Preference
                        </label>
                        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                          {RESTAURANT_INFO.seatingAreas.map((area) => (
                            <button
                              key={area}
                              type="button"
                              onClick={() => setResSeating(area)}
                              className={`rounded-lg border px-3 py-2 text-xs font-medium transition-colors duration-150 truncate ${
                                resSeating === area
                                  ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#D4AF37]'
                                  : 'border-white/10 bg-[#0A0A0B] text-[#A6A29A] hover:text-[#F7F5F0]'
                              }`}
                            >
                              {area}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* 7. Special Request */}
                      <div>
                        <label
                          htmlFor="res-request"
                          className="mb-1.5 block text-xs font-medium text-[#A6A29A]"
                        >
                          Special Request (Allergies, Anniversary Setup, Deal Selection)
                        </label>
                        <textarea
                          id="res-request"
                          rows={3}
                          value={resSpecialRequest}
                          onChange={(e) => setResSpecialRequest(e.target.value)}
                          placeholder="Let us know if you are celebrating a milestone, prefer a quiet corner booth, or have dietary preferences..."
                          className="w-full rounded-lg border border-white/15 bg-[#0A0A0B] px-3.5 py-2.5 text-sm text-[#F7F5F0] placeholder-[#A6A29A]/40 focus:border-[#D4AF37] focus:outline-none"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full rounded-lg bg-[#D4AF37] px-6 py-3.5 text-sm font-semibold text-[#0A0A0B] transition-colors duration-150 hover:bg-[#e5c148] whitespace-nowrap"
                      >
                        Book Now
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 8. CONTACT US SECTION */}
        <section id="contact" className="border-b border-white/10 bg-[#0E0E11] py-20 lg:py-28">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
              <div>
                <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                  <span>Location & Concierge</span>
                  <span aria-hidden="true">·</span>
                  <span>Manhattan Culinary District</span>
                </div>
                <h2 className="mt-2 font-serif text-4xl font-semibold tracking-tight text-[#F7F5F0] sm:text-5xl">
                  Contact & Visit Royal Taste
                </h2>
              </div>
              <p className="max-w-md text-sm text-[#A6A29A]">
                Located at 742 Royal Velvet Avenue with dedicated evening valet and private
                chauffeur drop-off.
              </p>
            </div>

            <div className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-12">
              {/* Contact Information Column */}
              <div className="lg:col-span-5 space-y-6 rounded-2xl border border-white/10 bg-[#121215] p-6 sm:p-8">
                {/* Address */}
                <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-5">
                  <div>
                    <p className="text-xs text-[#D4AF37]">Restaurant Address</p>
                    <p className="mt-1 text-sm font-medium text-[#F7F5F0]">
                      {RESTAURANT_INFO.address}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyAddress}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#0A0A0B] px-3 py-1.5 text-xs font-medium text-[#A6A29A] transition-colors hover:border-[#D4AF37] hover:text-[#F7F5F0] whitespace-nowrap shrink-0"
                  >
                    {addressCopied ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Direct Phone & Email */}
                <div className="grid grid-cols-1 gap-4 border-b border-white/10 pb-5 sm:grid-cols-2">
                  <div>
                    <p className="text-xs text-[#D4AF37]">Reservations & Concierge</p>
                    <a
                      href="tel:+12125550198"
                      className="mt-1 block font-mono text-sm font-semibold tabular-nums text-[#F7F5F0] hover:text-[#D4AF37]"
                    >
                      {RESTAURANT_INFO.phone}
                    </a>
                  </div>
                  <div>
                    <p className="text-xs text-[#D4AF37]">Electronic Mail</p>
                    <a
                      href={`mailto:${RESTAURANT_INFO.email}`}
                      className="mt-1 block truncate text-sm font-medium text-[#F7F5F0] hover:text-[#D4AF37]"
                    >
                      {RESTAURANT_INFO.email}
                    </a>
                  </div>
                </div>

                {/* Opening Hours */}
                <div className="border-b border-white/10 pb-5">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-[#D4AF37]">Opening Hours</p>
                    <span className="text-xs text-emerald-400">Open Today · Seating Available</span>
                  </div>
                  <div className="mt-3 space-y-2.5 text-xs">
                    {RESTAURANT_INFO.hours.map((item) => (
                      <div key={item.days} className="flex items-center justify-between">
                        <span className="text-[#F7F5F0] font-medium">{item.days}</span>
                        <span className="font-mono tabular-nums text-[#A6A29A]">{item.time}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Social Media Links */}
                <div>
                  <p className="text-xs text-[#D4AF37]">Connect with Royal Taste</p>
                  <div className="mt-3 flex flex-wrap items-center gap-2.5">
                    {[
                      { name: 'Instagram', handle: '@royaltasterestaurant' },
                      { name: 'Facebook', handle: 'RoyalTasteNYC' },
                      { name: 'X / Twitter', handle: '@royaltastenyc' },
                      { name: 'Michelin Guide', handle: 'Listed 2026' },
                    ].map((social) => (
                      <a
                        key={social.name}
                        href="#reservation"
                        onClick={(e) => {
                          e.preventDefault();
                          scrollToSection('reservation');
                        }}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#0A0A0B] px-3 py-2 text-xs font-medium text-[#F7F5F0] transition-colors hover:border-[#D4AF37] hover:text-[#D4AF37] whitespace-nowrap"
                      >
                        <span>{social.name}</span>
                        <ArrowUpRight className="h-3.5 w-3.5 text-[#D4AF37]" />
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              {/* Google Maps Location & Arrival Guide Column */}
              <div className="lg:col-span-7 flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-[#121215]">
                {/* Embedded Google Maps Location */}
                <div className="relative h-80 w-full bg-[#0A0A0B] sm:h-96">
                  <iframe
                    title="Royal Taste Restaurant Google Maps Location"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.9503398796587!2d-74.0060!3d40.7195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2598a6f8b371b%3A0x60a0000000000000!2sTribeca%2C%20New%20York%2C%20NY%2010013!5e0!3m2!1sen!2sus!4v1700000000000!5m2!1sen!2sus"
                    className="h-full w-full border-0 opacity-85 contrast-125 grayscale-[35%]"
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>

                {/* Interactive Arrival Instructions Bar */}
                <div className="border-t border-white/10 p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="text-xs font-semibold text-[#D4AF37]">
                      Arrival & Parking Concierge
                    </span>
                    <div className="flex items-center gap-1 rounded-lg bg-[#0A0A0B] p-1 border border-white/10">
                      {(
                        [
                          { id: 'valet', label: 'Valet Courtyard' },
                          { id: 'subway', label: 'Subway & Transit' },
                          { id: 'private', label: 'Chauffeur Drop-Off' },
                        ] as const
                      ).map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setDirectionsMode(tab.id)}
                          className={`rounded-md px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                            directionsMode === tab.id
                              ? 'bg-[#D4AF37] text-[#0A0A0B] font-semibold'
                              : 'text-[#A6A29A] hover:text-[#F7F5F0]'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <p className="mt-3 text-xs leading-relaxed text-[#A6A29A]">
                    {directionsMode === 'valet' &&
                      'Complimentary evening valet is stationed directly in front of the brass lantern entrance at 742 Royal Velvet Avenue beginning at 5:00 PM daily.'}
                    {directionsMode === 'subway' &&
                      'Two blocks north of Franklin St Station (1 Train) and 4 minutes from Canal St Station (A, C, E, N, Q, R, W Lines).'}
                    {directionsMode === 'private' &&
                      'Private vehicles and black car services may pull into our heated cobblestone courtyard for covered entrance access.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER WITH FINAL CALL-TO-ACTION */}
      <footer className="bg-[#080809] text-[#F7F5F0]">
        {/* Final Call-to-Action Banner */}
        <div className="border-b border-white/10 bg-gradient-to-r from-[#170C0E] via-[#121215] to-[#17130C] py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
              <div className="space-y-2">
                <p className="text-xs text-[#D4AF37]">
                  Royal Taste Restaurant · {RESTAURANT_INFO.tagline}
                </p>
                <h2 className="font-serif text-3xl font-semibold tracking-tight text-[#F7F5F0] sm:text-4xl">
                  “Experience Great Food. Create Great Memories.”
                </h2>
              </div>
              <div className="flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => scrollToSection('reservation')}
                  className="rounded-lg bg-[#D4AF37] px-6 py-3.5 text-sm font-semibold text-[#0A0A0B] transition-colors duration-150 hover:bg-[#e5c148] whitespace-nowrap"
                >
                  Book a Table
                </button>
                <button
                  type="button"
                  onClick={() => setOrderDrawerOpen(true)}
                  className="rounded-lg border border-white/15 bg-[#121215] px-6 py-3.5 text-sm font-medium text-[#F7F5F0] transition-colors duration-150 hover:border-[#D4AF37] whitespace-nowrap"
                >
                  Order Online ({totalCartItems})
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Footer Columns */}
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-12">
            {/* Brand Column */}
            <div className="lg:col-span-4 space-y-4">
              <a
                href="#home"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('home');
                }}
                className="font-serif text-2xl font-bold tracking-tight text-[#F7F5F0]"
              >
                Royal Taste Restaurant
              </a>
              <p className="text-xs text-[#D4AF37]">{RESTAURANT_INFO.tagline}</p>
              <p className="max-w-sm text-sm leading-relaxed text-[#A6A29A]">
                An intimate live-fire dining house dedicated to dry-aged Wagyu cuts, 72-hour
                sourdough artisan pizzas, and handcrafted desserts in the heart of New York’s
                Culinary District.
              </p>
            </div>

            {/* Quick Links */}
            <div className="lg:col-span-2 space-y-3">
              <h3 className="text-xs font-semibold text-[#D4AF37]">Quick Navigation</h3>
              <ul className="space-y-2 text-sm text-[#A6A29A]">
                {navLinks.map((link) => (
                  <li key={link.id}>
                    <a
                      href={`#${link.id}`}
                      onClick={(e) => {
                        e.preventDefault();
                        scrollToSection(link.id);
                      }}
                      className="transition-colors hover:text-[#F7F5F0]"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Opening Hours */}
            <div className="lg:col-span-3 space-y-3">
              <h3 className="text-xs font-semibold text-[#D4AF37]">Opening Hours</h3>
              <div className="space-y-2.5 text-xs text-[#A6A29A]">
                {RESTAURANT_INFO.hours.map((h) => (
                  <div key={h.days}>
                    <p className="font-medium text-[#F7F5F0]">{h.days}</p>
                    <p className="font-mono tabular-nums text-[#D4AF37]">{h.time}</p>
                    <p className="text-[11px] text-[#A6A29A]/80">{h.kitchenNote}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Contact Info */}
            <div className="lg:col-span-3 space-y-3">
              <h3 className="text-xs font-semibold text-[#D4AF37]">Contact & Concierge</h3>
              <p className="text-xs leading-relaxed text-[#A6A29A]">{RESTAURANT_INFO.address}</p>
              <p className="font-mono text-sm font-semibold tabular-nums text-[#F7F5F0]">
                {RESTAURANT_INFO.phone}
              </p>
              <p className="text-xs text-[#A6A29A]">{RESTAURANT_INFO.email}</p>
            </div>
          </div>

          <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 text-xs text-[#A6A29A] sm:flex-row">
            <p>© {new Date().getFullYear()} Royal Taste Restaurant. All rights reserved.</p>
            <div className="flex items-center gap-6">
              <a
                href="#reservation"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('reservation');
                }}
                className="hover:text-[#F7F5F0]"
              >
                Private Dining Policy
              </a>
              <a
                href="#menu"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('menu');
                }}
                className="hover:text-[#F7F5F0]"
              >
                Allergen & Dietary Guide
              </a>
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('contact');
                }}
                className="hover:text-[#F7F5F0]"
              >
                Press & Careers
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Gallery Lightbox Modal */}
      {activeLightboxItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={activeLightboxItem.title}
          onClick={() => setActiveLightboxItem(null)}
        >
          <div
            className="relative max-w-3xl w-full overflow-hidden rounded-2xl border border-white/15 bg-[#121215] shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setActiveLightboxItem(null)}
              className="absolute top-4 right-4 z-10 flex h-10 w-10 items-center justify-center rounded-lg bg-black/70 text-[#F7F5F0] hover:text-[#D4AF37]"
              aria-label="Close gallery preview"
            >
              <X className="h-5 w-5" />
            </button>
            <CulinaryVisual
              visualKey={activeLightboxItem.visualKey}
              alt={activeLightboxItem.title}
              aspectClass="aspect-[16/10]"
            />
            <div className="p-6 space-y-2">
              <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
                <span>{activeLightboxItem.category}</span>
                <span aria-hidden="true">·</span>
                <span className="text-[#A6A29A]">{activeLightboxItem.lightingNote}</span>
              </div>
              <h3 className="font-serif text-2xl font-semibold text-[#F7F5F0]">
                {activeLightboxItem.title}
              </h3>
              <p className="text-sm text-[#A6A29A]">{activeLightboxItem.caption}</p>
              <div className="pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setActiveLightboxItem(null);
                    scrollToSection('reservation');
                  }}
                  className="rounded-lg bg-[#D4AF37] px-4 py-2 text-xs font-semibold text-[#0A0A0B]"
                >
                  Book This Experience
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Slide-Over Order Drawer */}
      <OrderDrawer
        isOpen={orderDrawerOpen}
        onClose={() => setOrderDrawerOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />
    </div>
  );
}

const rtRoot = document.getElementById('root');
if (rtRoot && window.ReactDOM) {
  ReactDOM.createRoot(rtRoot).render(React.createElement(App));
}
